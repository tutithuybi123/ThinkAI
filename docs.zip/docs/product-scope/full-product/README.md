# ThinkAI Full Product scope

This directory describes the mature product direction, not a build commitment. The Competition Demo is frozen by ThinkAI Team Lead under `../competition-demo/`.

Core thesis: ThinkAI helps a learner learn with AI, records the conditions under which assistance contributed to success, then seeks bounded independent evidence in a changed situation and preserves the resulting history over time.
