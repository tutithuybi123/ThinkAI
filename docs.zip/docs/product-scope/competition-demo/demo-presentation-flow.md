# Three-minute presentation flow

0:00–0:20: show why correctness alone is incomplete: the learner opens a reviewed strategy hint.

0:20–1:05: live API-backed practice attempt, reviewed hint exposure and labelled live AI reasoning feedback; submit is deterministically scored.

1:05–1:55: isolated **Thử vận dụng** in a visibly changed representation; pass and reveal the reviewed connection.

1:55–2:25: **Xác nhận kỹ năng** states what was demonstrated and what has not yet been checked.

2:25–2:45: progress plus clearly labelled historical delayed event.

2:45–3:00: compact presenter audit: versions, hint exposure, pair review/provenance and evidence. Do not show a roadmap, fake retention, generic chat or an LMS.
